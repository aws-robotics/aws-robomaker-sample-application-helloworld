# AWS RoboMaker WorldForge Shared Models

This a ROS workspace for models shared by worlds contained in the `aws_robomaker_worldforge_worlds` package. See its README.md for instructions.
